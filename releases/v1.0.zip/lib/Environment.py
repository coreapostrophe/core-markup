class Environment:
    ui_width = 50
    max_probability_weight = 3