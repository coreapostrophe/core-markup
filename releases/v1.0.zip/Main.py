from lib.StudyManager import StudyManager

studyManager = StudyManager()
studyManager.render()